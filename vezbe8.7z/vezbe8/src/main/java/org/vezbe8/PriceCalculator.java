package org.vezbe8;

import org.vezbe8.model.Item;
import org.vezbe8.model.User;

public class PriceCalculator {

    public DiscountCalculator discountCalculator;
    public UserService userService;
    public ItemService itemService;

    public PriceCalculator(DiscountCalculator discountCalculator, UserService userService, ItemService itemService){
        this.discountCalculator = discountCalculator;
        this.userService = userService;
        this.itemService = itemService;
    }

    public double calculatePrice(int itemBarCode, String userId) {
        double price = 0;

        Item item = itemService.getItemDetails(itemBarCode);

        User user = userService.getUser(userId);
        double basePrice = item.getPrice();
        price = basePrice - (basePrice * (item.getApplicableDiscount() +
                user.getExtraLoyaltyDiscountPercentage())/100);

        return price;
    }


    public double calculatePriceLoyalty(int itemBarCode, String userId) {
        double price = 0;

        Item item = itemService.getItemDetails(itemBarCode);

        User user = userService.getUser(userId);
        double basePrice = item.getPrice();
        price = basePrice - (basePrice * (item.getApplicableDiscount() +
                user.getExtraLoyaltyDiscountPercentage())/100) - discountCalculator.calculateDiscount(item, user);

        return price;
    }

    public double calculateProfitability(int itemBarCode, String userId){
        Item item = itemService.getItemDetails(itemBarCode);

        double price = calculatePrice(itemBarCode, userId);

        return price - item.getCost();
    }


    public double calculateProfitabilityLoyalty(int itemBarCode, String userId){
        Item item = itemService.getItemDetails(itemBarCode);

        double price = calculatePriceLoyalty(itemBarCode, userId);

        return price - item.getCost();
    }
}
