package org.vezbe8;

import org.vezbe8.model.Item;

public interface ItemService {
    Item getItemDetails(int barCode);
}
