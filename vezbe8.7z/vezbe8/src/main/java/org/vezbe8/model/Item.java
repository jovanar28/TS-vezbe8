package org.vezbe8.model;

public class Item {
    private int barCode;
    private double price;
    private double cost;
    private int totalQuantity;
    private double applicableDiscount;

    public double getApplicableDiscount() {
        return applicableDiscount;
    }

    public void setApplicableDiscount(double applicableDiscount) {
        this.applicableDiscount = applicableDiscount;
    }

    public int getTotalQuantity() {
        return totalQuantity;
    }

    public void setTotalQuantity(int totalQuantity) {
        this.totalQuantity = totalQuantity;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public double getCost() {
        return cost;
    }

    public void setCost(double cost) {
        this.cost = cost;
    }

    public int getBarCode() {
        return barCode;
    }

    public void setBarCode(int barCode) {
        this.barCode = barCode;
    }
}
