package org.vezbe8.model;

public class User {

    private String name;
    private LoyaltyTier loyaltyTier;
    private String accountId;
    private double extraLoyaltyDiscountPercentage;

    public double getExtraLoyaltyDiscountPercentage() {
        return extraLoyaltyDiscountPercentage;
    }

    public void setExtraLoyaltyDiscountPercentage(double extraLoyaltyDiscountPercentage) {
        this.extraLoyaltyDiscountPercentage = extraLoyaltyDiscountPercentage;
    }
    public String getAccountId() {
        return accountId;
    }

    public void setAccountId(String accountId) {
        this.accountId = accountId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public LoyaltyTier getLoyaltyTier() {
        return loyaltyTier;
    }

    public void setLoyaltyTier(LoyaltyTier loyaltyTier) {
        this.loyaltyTier = loyaltyTier;
    }
}
