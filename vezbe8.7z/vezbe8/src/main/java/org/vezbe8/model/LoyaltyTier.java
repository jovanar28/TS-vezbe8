package org.vezbe8.model;

public enum LoyaltyTier {

    BRONZE, SILVER, GOLD
}
