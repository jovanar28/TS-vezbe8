package org.vezbe8;

import org.vezbe8.model.Item;
import org.vezbe8.model.User;

public interface DiscountCalculator {
    double calculateDiscount(Item item, User user);
}
