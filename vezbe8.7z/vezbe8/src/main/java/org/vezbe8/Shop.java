package org.vezbe8;

public class Shop {
}
