package org.vezbe8;

import org.vezbe8.model.User;

public interface UserService {

    void addUser(User user);
    void deleteUser(User user);
    User getUser(String customerAccountId);
}
