package org.vezbe8.impl;

import org.vezbe8.UserService;
import org.vezbe8.model.User;

import java.util.HashMap;
import java.util.Map;

public class UserServiceImpl implements UserService {

    private static Map<String, User> db = new HashMap<>();

    @Override
    public void addUser(User user) {
        db.put(user.getAccountId(),user);
    }

    @Override
    public void deleteUser(User user) {
        db.remove(user.getAccountId());
    }

    @Override
    public User getUser(String accountId) {
        return db.get(accountId);
    }
}
