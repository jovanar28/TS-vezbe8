package org.vezbe8.impl;

import org.vezbe8.DiscountCalculator;
import org.vezbe8.model.Item;
import org.vezbe8.model.LoyaltyTier;
import org.vezbe8.model.User;

public class DiscountCalculatorImpl implements DiscountCalculator {

    @Override
    public double calculateDiscount(Item item, User user) {
        LoyaltyTier tier = user.getLoyaltyTier();
        switch (tier){
            case BRONZE -> {
                return item.getPrice() * 0.1;
            }
            case SILVER -> {
                return item.getPrice() * 0.2;
            }
            case GOLD -> {
                return item.getPrice() * 0.3;
            }
        }
        return 0;
    }

}
