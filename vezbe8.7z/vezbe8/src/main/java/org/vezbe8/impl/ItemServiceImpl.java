package org.vezbe8.impl;

import org.vezbe8.ItemService;
import org.vezbe8.model.Item;

public class ItemServiceImpl implements ItemService {
    @Override
    public Item getItemDetails(int barCode) {
        Item item = new Item();
        item.setPrice(200);
        item.setApplicableDiscount(10);
        return item;
    }
}
