package org.task2;

public interface PriceService {

    double getPrice(long movieId);
}
