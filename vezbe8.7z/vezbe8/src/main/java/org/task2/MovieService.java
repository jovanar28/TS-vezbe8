package org.task2;

import org.task2.model.Movie;

public interface MovieService {
    Movie getMovie(long movieId);
}
