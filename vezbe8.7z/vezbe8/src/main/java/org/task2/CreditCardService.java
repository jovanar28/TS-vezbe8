package org.task2;

import org.task2.model.CreditCard;

public interface CreditCardService {

    CreditCard getCreditCardByUser(long userId);

    CreditCard getCreditCard(long creditCardId);

}
