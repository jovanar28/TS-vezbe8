package org.task2;

import org.task2.model.User;

public interface UserService {
    User getUser(long userId);
}
