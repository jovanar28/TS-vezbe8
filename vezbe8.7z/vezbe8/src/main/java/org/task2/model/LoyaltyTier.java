package org.task2.model;

public enum LoyaltyTier {

    BRONZE, SILVER, GOLD
}
