package org.task2.model;

public class Movie {

    private long id;

    private String name;

    private int seats;

    private int length;

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getLength() {
        return length;
    }

    public void setLength(int length) {
        this.length = length;
    }

    public int getSeats() {
        return seats;
    }

    public void soldSeats(int seats) {
        this.seats -= seats;
    }

    public Movie(long id, String name, int length, int seats) {
        this.id = id;
        this.name = name;
        this.length = length;
        this.seats = seats;
    }

}
