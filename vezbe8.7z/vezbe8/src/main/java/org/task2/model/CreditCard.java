package org.task2.model;

public class CreditCard {

    private long id;

    private long UserId;

    private long amount;

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public long getUserId() {
        return UserId;
    }

    public void setUserId(long userId) {
        UserId = userId;
    }

    public long getAmount() {
        return amount;
    }

    public void setAmount(long amount) {
        this.amount = amount;
    }

    public CreditCard(long id, long userId, long amount) {
        this.id = id;
        UserId = userId;
        this.amount = amount;
    }
}
