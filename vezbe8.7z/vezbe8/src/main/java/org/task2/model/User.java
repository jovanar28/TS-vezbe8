package org.task2.model;

import org.vezbe8.model.LoyaltyTier;

public class User {

    private long id;

    private String name;

    private LoyaltyTier loyaltyTier;

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }


    public LoyaltyTier getLoyaltyTier() {
        return loyaltyTier;
    }

    public void setLoyaltyTier(LoyaltyTier loyaltyTier) {
        this.loyaltyTier = loyaltyTier;
    }

    public User(long id, String name, LoyaltyTier loyaltyTier) {
        this.id = id;
        this.name = name;
        this.loyaltyTier = loyaltyTier;
    }
}
