package org.task2;

import org.task2.model.CreditCard;
import org.task2.model.Movie;
import org.task2.model.User;
import org.task2.UserService;

public class MovieTheatre {

    private long profit;

    private  UserService userService;

    private MovieService movieService;

    private CreditCardService creditCardService;

    private PriceService priceService;

    public MovieTheatre(UserService userService, MovieService movieService, CreditCardService creditCardService, PriceService priceService) {
        this.userService = userService;
        this.movieService = movieService;
        this.creditCardService = creditCardService;
        this.priceService = priceService;
        this.profit = 0;
    }

    public boolean sellTickets(long movieId, long userId, int numberOfTickets){
        Movie movie = movieService.getMovie(movieId);
        CreditCard creditCard = creditCardService.getCreditCardByUser(userId);
        double price = numberOfTickets * priceService.getPrice(movieId);

        if (creditCard.getAmount() > price){
            creditCard.setAmount((long) (creditCard.getAmount() - price));
            profit += price;
            movie.soldSeats(numberOfTickets);
            return true;
        }
        return false;
    }

    public long getProfit() {
        return profit;
    }

    public void setProfit(long profit) {
        this.profit = profit;
    }
}
