package org.example;

public class UserService{

    private final UserRepository1 userRepository1;
    private final PasswordEncoder1 passwordEncoder1;

    public UserService(UserRepository1 userRepository1, PasswordEncoder1 passwordEncoder1) {
        this.userRepository1 = userRepository1;
        this.passwordEncoder1 = passwordEncoder1;
    }

    public boolean isValidUser(String id, String password) {
        User1 user1 = userRepository1.findById(id);
        return isEnabledUser(user1) && isValidPassword(user1, password);
    }

    private boolean isEnabledUser(User1 user1) {
        return user1 != null && user1.isEnabled();
    }

    private boolean isValidPassword(User1 user1, String password) {
        String encodedPassword = passwordEncoder1.encode(password);
        return encodedPassword.equals(user1.getPasswordHash());
    }
}
