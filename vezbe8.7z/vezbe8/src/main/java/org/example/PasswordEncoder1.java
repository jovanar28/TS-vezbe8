package org.example;

public interface PasswordEncoder1 {
    String encode(String password);
}
