package org.example;

public interface UserRepository1 {

    User1 findById(String id);
}
