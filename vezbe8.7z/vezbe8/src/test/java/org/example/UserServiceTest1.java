package org.example;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;


import static org.mockito.ArgumentMatchers.anyString;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;


@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
class UserServiceTest1 {

    private static final String password="password";
    private static final User1 ENABLED=new User1("user_id","hash",true);
    private static final User1 DISABLED=new User1("disabled_user_id","disabled user hash",false);

    @Mock
    private UserRepository1 userRepository1;
    @Mock
    private PasswordEncoder1 passwordEncoder1;
    @InjectMocks
    private UserService userService;

    @BeforeEach
    void setup(){
        when(userRepository1.findById("user_id")).thenReturn(ENABLED);
        when(userRepository1.findById("disabled_user_id")).thenReturn(DISABLED);

        //bitan redosled
        when(passwordEncoder1.encode(anyString())).thenReturn("invalid");
        when(passwordEncoder1.encode(password)).thenReturn("hash");

    }


    @Test
    void validUser(){
        boolean isValid=userService.isValidUser(ENABLED.getId(),password);
        assertTrue(isValid);
        verify(userRepository1).findById(anyString());
        verify(passwordEncoder1).encode(anyString());

    }
    //disabled user i
    @Test
    void disabledUser(){
        boolean isValid=userService.isValidUser(DISABLED.getId(),password);
        assertFalse(isValid);
        verify(userRepository1).findById(anyString());
        verify(passwordEncoder1).encode(anyString());

    }

    @Test
    void invalidPassword(){
        boolean isValid=userService.isValidUser(ENABLED.getId(),"sta god");
        assertFalse(isValid);
        verify(userRepository1).findById(anyString());
        verify(passwordEncoder1).encode("sta god");

    }
    @Test
    void invalidUserId(){
        boolean isValid=userService.isValidUser("id",password);
        assertFalse(isValid);
        verify(userRepository1).findById("id");
        verify(passwordEncoder1,never()).encode(anyString());

    }






}