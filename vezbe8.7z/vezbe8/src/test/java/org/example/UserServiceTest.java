package org.example;


import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.mockito.InOrder;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;

/**
 * Shows how to use mock(), verify(), inOrder(), ArgumentCaptor and argument matchers.
 */
public class UserServiceTest {

    private static final String PASSWORD = "password";
    private static final User1 ENABLED_USER = new User1("user id", "hash", true);
    private static final User1 DISABLED_USER = new User1("disabled user id", "disabled user password hash", false);
    
    private UserRepository1 userRepository;
    private PasswordEncoder1 passwordEncoder;
    private UserService userService;

    @BeforeEach
    public void setup() {
        userRepository = createUserRepository();
        passwordEncoder = createPasswordEncoder();
        userService = new UserService(userRepository, passwordEncoder);
    }

    @Test
    public void shouldBeValidForValidCredentials() {
        boolean userIsValid = userService.isValidUser(ENABLED_USER.getId(), PASSWORD);
        assertTrue(userIsValid);

        // userRepository had to be used to find a user with id="user id"
        verify(userRepository).findById(ENABLED_USER.getId());

        // passwordEncoder had to be used to compute a hash of "password"
        verify(passwordEncoder).encode(PASSWORD);
    }

    @Test
    public void shouldBeInvalidForInvalidId() {
        boolean userIsValid = userService.isValidUser("invalid id", PASSWORD);
        assertFalse(userIsValid);

        InOrder inOrder = inOrder(userRepository, passwordEncoder);
        inOrder.verify(userRepository).findById("invalid id");
        inOrder.verify(passwordEncoder, never()).encode(anyString());
    }


    @Test
    public void shouldBeInvalidForDisabledUser() {
        boolean userIsValid = userService.isValidUser(DISABLED_USER.getId(), PASSWORD);
        assertFalse(userIsValid);

        verify(userRepository).findById(DISABLED_USER.getId());
        verifyNoInteractions(passwordEncoder);
    }

    private PasswordEncoder1 createPasswordEncoder() {
        PasswordEncoder1 mock = mock(PasswordEncoder1.class);
        when(mock.encode(anyString())).thenReturn("any password hash");
        when(mock.encode(PASSWORD)).thenReturn(ENABLED_USER.getPasswordHash());
        return mock;
    }

    private UserRepository1 createUserRepository() {
        UserRepository1 mock = mock(UserRepository1.class);
        when(mock.findById(ENABLED_USER.getId())).thenReturn(ENABLED_USER);
        when(mock.findById(DISABLED_USER.getId())).thenReturn(DISABLED_USER);
        return mock;
    }
}