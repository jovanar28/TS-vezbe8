package org.example;

import org.junit.jupiter.api.Test;

import static org.mockito.Mockito.*;

public class ClearInvocationsTest {

    @Test
    public void clearInvocationsTest() {
        PasswordEncoder1 passwordEncoder = mock(PasswordEncoder1.class);
        UserRepository1 userRepository = mock(UserRepository1.class);

        // use mocks
        passwordEncoder.encode(null);
        userRepository.findById(null);

        // clear
        clearInvocations(passwordEncoder, userRepository);

        // succeeds because invocations were cleared
        verifyNoInteractions(passwordEncoder, userRepository);
    }
}
