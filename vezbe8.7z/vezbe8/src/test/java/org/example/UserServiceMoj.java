package org.example;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;
import org.vezbe8.model.User;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
public class UserServiceMoj {

    private static final String password="password";
    private static final User1 ENABLED=new User1("user id","hash",true);
    private static final User1 DISABLED=new User1("dis id","disabled user hash",false);

    @Mock
    private UserRepository1 userRepository1;
    @Mock
    private PasswordEncoder1 passwordEncoder1;
    @InjectMocks
    private UserService userService;

    @BeforeEach
    void setup(){
        when(userRepository1.findById(ENABLED.getId())).thenReturn(ENABLED);
        when(userRepository1.findById(DISABLED.getId())).thenReturn(DISABLED);

        when(passwordEncoder1.encode(anyString())).thenReturn("invalid password");
        when(passwordEncoder1.encode(password)).thenReturn("hash");

    }

    @Test
    void validUser(){
        boolean isValid=userService.isValidUser(ENABLED.getId(),password);
        assertTrue(isValid);
        verify(userRepository1).findById(anyString());
        verify(passwordEncoder1).encode(anyString());

    }

    @Test
    void disabledUser(){
        boolean isValid=userService.isValidUser(DISABLED.getId(),password);
        assertFalse(isValid);
        verify(userRepository1).findById(anyString());
        verify(passwordEncoder1,never()).encode(anyString());

    }
}
