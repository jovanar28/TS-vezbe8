package org.task1;

import static org.junit.jupiter.api.Assertions.*;

class AudioManagerTest {


}