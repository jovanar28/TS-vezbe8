package org.task1;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)

class VolumeUtilTest1 {

    @Spy
    private AudioManager audioManager;
    //getRingerMode ima impl pa moze  spy

    @Test
    void makeReallyLoudTest(){
        //stubovanje get metode
        when(audioManager.getRingerMode()).thenReturn(RINGER_MODE.RINGER_MODE_NORMAL);

        int volume=VolumeUtil.makeReallyLoad(audioManager);
        assertEquals(volume,100);

        verify(audioManager).setStreamVolume(anyInt());
    }

    @Test
    void test2(){

        int volume=VolumeUtil.makeReallyLoad(audioManager);
        assertEquals(volume,50);
        verify(audioManager,never()).setStreamVolume(anyInt());
    }

}