package org.vezbe8;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;
import org.vezbe8.model.Item;
import org.vezbe8.model.LoyaltyTier;
import org.vezbe8.model.User;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
class PriceCalculatorTest {

    @Mock
    public DiscountCalculator discountCalculator;
    @Mock
    public UserService userService;
    @Mock
    public ItemService itemService;

    @InjectMocks
    @Spy
    private PriceCalculator priceCalculator;


    @Test
    void calculatePriceTest(){
        //posto metoda calculateprice ima arg itemBarCode i userId
        //mi ih stub:
        Item item=new Item();
        item.setPrice(100);
        item.setBarCode(1);
        item.setApplicableDiscount(5);
        when(itemService.getItemDetails(anyInt())).thenReturn(item);

        User user=new User();
        user.setAccountId("id");
        user.setExtraLoyaltyDiscountPercentage(10);

        when(userService.getUser(anyString())).thenReturn(user);

        double price=priceCalculator.calculatePrice(1,"id");
        assertEquals(85,price);

        verify(itemService).getItemDetails(anyInt());
        verify(userService).getUser(anyString());
    }

    @Test
    void calculatePriceLoyaltyTest(){
        Item item=new Item();
        item.setPrice(100);
        item.setBarCode(1);
        item.setApplicableDiscount(5);
        when(itemService.getItemDetails(anyInt())).thenReturn(item);

        User user=new User();
        user.setAccountId("id");
        user.setExtraLoyaltyDiscountPercentage(10);
        user.setLoyaltyTier(LoyaltyTier.BRONZE);

        when(userService.getUser(anyString())).thenReturn(user);

        double price=priceCalculator.calculatePriceLoyalty(1,"id");
        assertEquals(85,price);

        verify(discountCalculator).calculateDiscount(item,any());

        when(discountCalculator.calculateDiscount(any(),any())).thenReturn(10.0);
        price=priceCalculator.calculatePriceLoyalty(1,"id");
        assertEquals(75,price);
    }


    @Test
    void calculateProfitabilityTest(){
        Item item=new Item();
        item.setPrice(100);
        item.setCost(50);
        item.setBarCode(1);
        item.setApplicableDiscount(5);
        when(itemService.getItemDetails(anyInt())).thenReturn(item);

        User user=new User();
        user.setAccountId("id");
        user.setExtraLoyaltyDiscountPercentage(10);
        user.setLoyaltyTier(LoyaltyTier.BRONZE);
        when(userService.getUser(anyString())).thenReturn(user);

        double price=priceCalculator.calculateProfitability(1,"id");
        assertEquals(35,price);

       // verify(priceCalculator).calculatePrice(1,"id");
        verify(itemService,times(2)).getItemDetails(1);
        verify(userService).getUser("id");

    }
    @Test
    void calculateProfitabilityLoyaltyTest(){
        Item item=new Item();
        item.setPrice(100);
        item.setCost(50);
        item.setBarCode(1);
        item.setApplicableDiscount(5);
        when(itemService.getItemDetails(anyInt())).thenReturn(item);

        User user=new User();
        user.setAccountId("id");
        user.setExtraLoyaltyDiscountPercentage(10);
        user.setLoyaltyTier(LoyaltyTier.BRONZE);
        when(userService.getUser(anyString())).thenReturn(user);

        double price=priceCalculator.calculateProfitabilityLoyalty(1,"id");
        assertEquals(25,price);

         verify(priceCalculator).calculatePriceLoyalty(1,"id");

    }

    @Test
    void test(){
        when(userService.getUser("")).thenThrow(RuntimeException.class);
        assertThrows(RuntimeException.class, ()->
                priceCalculator.calculatePrice(1,""));
    }

}