package org.vezbe8;


import org.example.PasswordEncoder1;
import org.example.UserRepository1;
import org.example.UserService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoInteractions;
import static org.mockito.internal.util.MockUtil.isMock;

public class AnnotationsTest {


    @Mock
    private PasswordEncoder1 passwordEncoder;

    @Mock
    private UserRepository1 userRepository;

    @InjectMocks
    private UserService userService;
    //umesto constructor

    //ovako!!!
    @BeforeEach
    public void beforeTest() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    public void test1() {
        passwordEncoder.encode("1");
        verify(passwordEncoder).encode(anyString());
    }

    @Test
    public void test2() {
        verifyNoInteractions(passwordEncoder, userRepository);
        assertFalse(isMock(userService));
    }
}
