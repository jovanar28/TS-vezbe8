package org.vezbe8;


import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.*;

@ExtendWith(value = MockitoExtension.class)
public class SpyTest {

    @Test
    public void test() {
        List<Integer> list = spy(ArrayList.class);
        list.add(42);
        assertEquals(42, list.get(0));
        verify(list).add(anyInt());
        verify(list).get(anyInt());

    }

    // Write a test named TestingSpy. Configure a List<String> with the @Spy annotation to
    // return a certain string for the get(10000000) in the list.

    @Test
    public void testingSpy(){
        List<String>lista=spy(ArrayList.class);
        //da je bio mock
        //List<String> lista=mock(ArrayList.class);
        //vraca null umesto primer1 jer mi smo stubovali da je arraylista
        lista.add("primer1");
        doReturn("Big list").when(lista).get(10000000);

        assertEquals("primer1",lista.get(0));
        assertEquals("Big list",lista.get(10000000));

        verify(lista,times(2)).get(anyInt());
    }

    //moramo da dodamo @Extendswith za @Spy
    @Spy
    //damo impl a ne interface(list)
    ArrayList<String>lista;
    @Test
    public void test1(){
        lista.add("primer1");
        doReturn("Big list").when(lista).get(10000000);

        assertEquals("primer1",lista.get(0));
        assertEquals("Big list",lista.get(10000000));

        verify(lista,times(2)).get(anyInt());

    }
}
