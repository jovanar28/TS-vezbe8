package org.vezbe8;

import org.example.PasswordEncoder1;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Captor;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class ArgumentCaptorTest {

    @Test
    public void testSingleCall() {
        PasswordEncoder1 passwordEncoder = mock(PasswordEncoder1.class);

        passwordEncoder.encode("password");

        ArgumentCaptor<String> passwordCaptor = ArgumentCaptor.forClass(String.class);
        verify(passwordEncoder).encode(passwordCaptor.capture());

        assertEquals("password", passwordCaptor.getValue());
    }

    @Test
    public void testMultipleCalls() {
        PasswordEncoder1 passwordEncoder = mock(PasswordEncoder1.class);

        passwordEncoder.encode("password1");
        passwordEncoder.encode("password2");
        passwordEncoder.encode("password3");

        ArgumentCaptor<String> passwordCaptor = ArgumentCaptor.forClass(String.class);
        verify(passwordEncoder, times(3)).encode(passwordCaptor.capture());

        assertEquals(Arrays.asList("password1", "password2", "password3"),
                     passwordCaptor.getAllValues());
    }

    @Test
    public void shouldContainCertainListItem1() {
        List<String> mockedList = mock(List.class);
        List<String> asList = Arrays.asList("someElement_test", "someElement");
        mockedList.addAll(asList);
        ArgumentCaptor<List<String>> captor = ArgumentCaptor.forClass(List.class);
        verify(mockedList).addAll(captor.capture());
        List<String> capturedArgument = captor.getValue();
        assertTrue(capturedArgument.contains("someElement"));
    }


    @Captor
    private ArgumentCaptor<List<String>> captor;

    @Test
    public final void shouldContainCertainListItem2(@Mock List<String> mockedList) {
        var asList = Arrays.asList("someElement_test", "someElement");
        mockedList.addAll(asList);

        verify(mockedList).addAll(captor.capture());
        List<String> capturedArgument = captor.getValue();
        assertTrue(capturedArgument.contains("someElement"));
    }
}
