package org.vezbe8;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Spy;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;
import org.vezbe8.impl.DiscountCalculatorImpl;
import org.vezbe8.model.Item;
import org.vezbe8.model.LoyaltyTier;
import org.vezbe8.model.User;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
public class PriceCalculatorTestSpy {

    @Spy
    private DiscountCalculatorImpl discountCalculator;
    @Mock
    private ItemService itemService;
    @Mock
    private UserService userService;
    @InjectMocks
    private PriceCalculator priceCalculator;

    @Test
    void calculatePriceLoyaltyTest(){
        Item item=new Item();
        item.setPrice(100);
        item.setBarCode(1);
        item.setApplicableDiscount(5);
        when(itemService.getItemDetails(anyInt())).thenReturn(item);

        User user=new User();
        user.setAccountId("id");
        user.setExtraLoyaltyDiscountPercentage(10);
        user.setLoyaltyTier(LoyaltyTier.BRONZE);

        when(userService.getUser(anyString())).thenReturn(user);

        double price=priceCalculator.calculatePriceLoyalty(1,"id");
        assertEquals(75,price);

        verify(discountCalculator).calculateDiscount(any(),any());

        doReturn(20.0).when(discountCalculator).calculateDiscount(any(),any());
        price=priceCalculator.calculatePriceLoyalty(1,"id");
        assertEquals(65,price);
    }
}
