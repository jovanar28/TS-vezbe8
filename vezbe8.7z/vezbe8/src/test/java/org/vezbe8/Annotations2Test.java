package org.vezbe8;


import org.example.PasswordEncoder1;
import org.example.UserRepository1;
import org.example.UserService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.verifyNoInteractions;
import static org.mockito.internal.util.MockUtil.isMock;

//ili preko extension!!!!
//potreban depedency za ovu opciju
@ExtendWith(MockitoExtension.class)
public class Annotations2Test {

    @Mock
    private PasswordEncoder1 passwordEncoder;

    @Mock
    private UserRepository1 userRepository;

    @InjectMocks
    private UserService userService;

    @Test
    public void test1() {
        passwordEncoder.encode("1");
        verify(passwordEncoder).encode(anyString());
    }

    @Test
    public void test2() {
        verifyNoInteractions(passwordEncoder, userRepository);
        assertFalse(isMock(userService));
    }
}
